For info on the annotation format and example code for visualising the instances, please refer to:

https://github.com/HeylenJonas/KITTI3D-Instance-Segmentation-Devkit
